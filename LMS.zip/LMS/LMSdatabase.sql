
CREATE DATABASE LMSdatabase;

USE LMSdatabase;

CREATE TABLE LibraryMembers
(
	studentID INT PRIMARY KEY NOT NULL,
	firstname VARCHAR(30) NOT NULL,
	lastname VARCHAR(30) NOT NULL,
	gender VARCHAR(10) NOT NULL,
	email VARCHAR(60) NOT NULL,
	Mpassword VARCHAR(50) NOT NULL,
	request VARCHAR(30) NOT NULL
);

CREATE TABLE AdminMembers
(
	adminID INT PRIMARY KEY NOT NULL,
	firstname VARCHAR(30) NOT NULL,
	lastname VARCHAR(30) NOT NULL,
	gender VARCHAR(10) NOT NULL,
	email VARCHAR(60) NOT NULL,
	Apassword VARCHAR(50) NOT NULL
);

CREATE TABLE BookTitles
(
	booktitle VARCHAR(90) PRIMARY KEY NOT NULL,
	author VARCHAR(60) NOT NULL,
	rackdetails VARCHAR(60) NOT NULL,
	faculty VARCHAR(30) NOT NULL
);

CREATE TABLE Books
(
	booknumber INT PRIMARY KEY NOT NULL,
	booktitle VARCHAR(90) NOT NULL,
	bookstatus VARCHAR(30) NOT NULL,

	CONSTRAINT Books_FK FOREIGN KEY (booktitle) REFERENCES BookTitles (booktitle) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE Reserved
(
	studentID INT NOT NULL,
	booknumber INT NOT NULL,
	reservedate VARCHAR(60) NOT NULL,
	duedate VARCHAR(60) NOT NULL,
	duestatus VARCHAR(30) NOT NULL,

	CONSTRAINT Reserved_FK FOREIGN KEY (studentID) REFERENCES LibraryMembers (studentID) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT Reserved_FKK FOREIGN KEY (booknumber) REFERENCES Books (booknumber) ON DELETE CASCADE ON UPDATE CASCADE
);

INSERT INTO AdminMembers VALUES
(1001001, 'Moeketsi', 'Leseli', 'Male', 'moeketsileseli@gmail.com', 'login'),
(1001002, 'Puseletso', 'Ntoi', 'Female', 'puseletsontoi@gmail.com', 'ntoi');

INSERT INTO LibraryMembers VALUES 
(1923800, 'Justice', 'Ntoi', 'Male', 'justicentoi@gmail.com', '1234','approved'),
(1923801, 'Khabele', 'Leraisa', 'Male', 'khabza@gmail.com', '1345','approved'),
(1923802, 'Rethabile', 'Letshohlo', 'Male', 'rethabile12@gmail.com', 'retha123','approved'),
(1923803, 'Lisemelo', 'mahatlane', 'Female', 'lisemelo@gmail.com', '1234','pending'),
(1923804, 'Mosa', 'Lerotholi', 'Female', 'mosalerotholi@gmail.com', '1345','pending'),
(1923805, 'Lintshi', 'Letshohlo', 'Female', 'lintsi123@gmail.com', '4123','pending'),
(1923806, 'Lenka', 'tshehlo', 'Male', 'lenka247@gmail.com', '1234','pending'),
(1923807, 'Mohai', 'Nko', 'Male', 'mohainko@gmail.com', '1345','pending'),
(1923808, 'Tshepo', 'Lefohlo', 'Male', 'tshepolefohlo@gmail.com', '8123','pending'),
(1923809, 'Linkeng', 'Ntoi', 'Female', 'limkenghy@gmail.com', '17834','approved'),
(1923810, 'Likeleli', 'Mohapeloa', 'Female', 'likelelim12@gmail.com', '13dg45','approved'),
(1923811, 'Kekeletso', 'lelana', 'Female', 'keke567@gmail.com', '4574','approved');

INSERT INTO BookTitles VALUES
('Python Programming','Chris Williamson','section 1 row 1','COMPUTING'),
('Managing Software Organizations','Philip A. Laplante','section 1 row 1','COMPUTING'),
('Fundamentals of Software Engineering','Hitesh Mohapatra,','section 1 row 2','COMPUTING'),
('An Introduction to Software Engineering','Dr Laurie A Williams','section 1 row 2','COMPUTING'),
('Identification Refactoring and Management','Joanna F DeFranco','section 1 row 3','COMPUTING'),
('Antipatterns','Colin Jolin','section 1 row 3','COMPUTING'),
('Comparative Health Information Management','Oliver Jake','section 1 row 4','HEALTH AND EDUCATION'),
('Essentials of Health Information Management','Jack Connor','section 1 row 4','HEALTH AND EDUCATION'),
('Health Information Management Technology','Harry Callum','section 1 row 5','HEALTH AND EDUCATION'),
('Case Studies in Health Information Management','Jacob Jacob','section 1 row 5','HEALTH AND EDUCATION'),
('Health Care Information Systems','Charlie Kyle','section 2 row 1','HEALTH AND EDUCATION'),
('Information Systems for Healthcare Management','Thomas Joe','section 2 row 1','HEALTH AND EDUCATION'),
('Fundamentals of Law for Health Informatics','George Reece','section 2 row 2','HEALTH AND EDUCATION'),
('Health Information Management Concepts and Principles','Oscar Rhys','section 2 row 2','HEALTH AND EDUCATION'),
('Management of a Strategic Resource','James Charlie','section 2 row 3','HEALTH AND EDUCATION'),
('Legal and Ethical Aspects of Health Information Management','William Damian','section 2 row 3','HEALTH AND EDUCATION'),
('Accounting all in one for Dummies','Hashir Sumner','section 2 row 4','BUSINESS AND ACCOUTING'),
('Accounting for the Numberphobic','Kellie Mason','section 2 row 4','BUSINESS AND ACCOUTING'),
('Tax Savvy for Small Business','Krzysztof Mccann','section 2 row 5','BUSINESS AND ACCOUTING'),
('Profit First','Liam Dickinson','section 2 row 5','BUSINESS AND ACCOUTING'),
('Accounting Best Practices','Anees Sanders','section 3 row 1','BUSINESS AND ACCOUTING'),
('Warren Buffett Accounting Book','Caspar Alston','section 3 row 2','BUSINESS AND ACCOUTING');

INSERT INTO Books VALUES
(101,'Python Programming','Reserved'),(102,'Python Programming','Reserved'),(145,'Python Programming','Available'),
(103,'Managing Software Organizations','Reserved'),(104,'Managing Software Organizations','Reserved'),(146,'Managing Software Organizations','Available'),
(105,'Fundamentals of Software Engineering','Reserved'),(106,'Fundamentals of Software Engineering','Reserved'),
(107,'An Introduction to Software Engineering','Reserved'),(108,'An Introduction to Software Engineering','Reserved'),
(147,'An Introduction to Software Engineering','Available'),(148,'An Introduction to Software Engineering','Available'),
(109,'Identification Refactoring and Management','Reserved'),(110,'Identification Refactoring and Management','Reserved'),
(111,'Antipatterns','Reserved'),(112,'Antipatterns','Reserved'),(149,'Antipatterns','Available'),(150,'Antipatterns','Available'),(151,'Antipatterns','Available'),
(113,'Comparative Health Information Management','Reserved'),(114,'Comparative Health Information Management','Reserved'),
(152,'Comparative Health Information Management','Available'),(153,'Comparative Health Information Management','Available'),
(115,'Essentials of Health Information Management','Reserved'),(116,'Essentials of Health Information Management','Reserved'),
(117,'Health Information Management Technology','Available'),(118,'Health Information Management Technology','Available'),
(119,'Case Studies in Health Information Management','Available'),(120,'Case Studies in Health Information Management','Available'),
(121,'Health Care Information Systems','Available'),(122,'Health Care Information Systems','Available'),
(123,'Information Systems for Healthcare Management','Available'),(124,'Information Systems for Healthcare Management','Available'),
(125,'Fundamentals of Law for Health Informatics','Available'),(126,'Fundamentals of Law for Health Informatics','Available'),
(127,'Health Information Management Concepts and Principles','Available'),(128,'Health Information Management Concepts and Principles','Available'),
(129,'Management of a Strategic Resource','Available'),(130,'Management of a Strategic Resource','Available'),
(131,'Legal and Ethical Aspects of Health Information Management','Available'),(132,'Legal and Ethical Aspects of Health Information Management','Available'),
(133,'Accounting all in one for Dummies','Available'),(134,'Accounting all in one for Dummies','Available'),
(135,'Accounting for the Numberphobic','Available'),(136,'Accounting for the Numberphobic','Available'),
(137,'Tax Savvy for Small Business','Available'),(138,'Tax Savvy for Small Business','Available'),
(139,'Profit First','Available'),(140,'Profit First','Available'),
(141,'Accounting Best Practices','Available'),(142,'Accounting Best Practices','Available'),
(143,'Warren Buffett Accounting Book','Available'),(144,'Warren Buffett Accounting Book','Available');

INSERT INTO Reserved VALUES
(1923801, 101, '13/04/2022 13:10:18', '19/04/2022 13:10:18', 'ondue'),(1923801, 103, '15/05/2022 08:30:18', '21/05/2022 08:30:18', 'ondue'),
(1923801, 102, '13/04/2022 10:00:30', '19/04/2022 10:00:30', 'ondue'),(1923802, 104, '15/05/2022 13:00:30', '21/05/2022 13:00:30', 'ondue'),
(1923803, 105, '14/04/2022 11:15:30', '20/04/2022 11:15:30', 'ondue'),(1923802, 106, '19/05/2022 09:40:03', '24/05/2022 09:40:03', 'ondue'),
(1923804, 107, '14/04/2022 14:00:30', '20/04/2022 14:00:30', 'overdue'),(1923804, 108, '19/05/2022 14:13:03', '24/05/2022 14:13:03', 'ondue'),
(1923806, 109, '14/04/2022 12:40:15', '20/04/2022 12:40:15', 'overdue'),(1923805, 110, '20/05/2022 15:30:15', '26/05/2022 15:30:15', 'ondue'),
(1923806, 111, '14/04/2022 14:20:10', '14/04/2022 14:20:10', 'overdue'),(1923811, 112, '21/05/2022 07:12:02', '27/05/2022 07:12:02', 'ondue'),
(1923809, 113, '16/04/2022 11:20:40', '22/04/2022 11:20:40', 'overdue'),(1923807, 114, '21/05/2022 12:12:02', '27/05/2022 12:12:02', 'ondue'),
(1923810, 115, '20/04/2022 08:58:02', '26/04/2022 08:58:02', 'overdue'),(1923808, 116, '22/05/2022 14:10:42', '28/05/2022 14:10:42', 'ondue'),
(1923800, 150, '13/04/2022 13:10:18', '19/04/2022 13:10:18', 'ondue'),(1923800, 146, '13/04/2022 13:10:18', '19/04/2022 13:10:18', 'ondue');