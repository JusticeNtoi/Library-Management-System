/**
 * 
 */
 
 const navSlide = () => {
	const lines = document.querySelector('.lines');
	const nav = document.querySelector('.nav-ul');
	const navul = document.querySelectorAll('.nav-ul li');
	
	
	lines.addEventListener('click',() => {
		//toggle navigation
		nav.classList.toggle('nav-active');
		
		//toggle links
		navul.forEach((link, index) => {
			if(link.style.animation) {
				link.style.animation = '';
			}
			else {
				link.style.animation = `navulfade 0.5s ease forwards ${index / 3 + 0.2}s`;
			}
		});
		
		//lines animation
		lines.classList.toggle('toggle');
	});
	

}

navSlide();