/**
 *  
 */

function check()
{   
 var num1 = document.getElementById("password").value;
 var num2 = document.getElementById("comfirm").value;
 var num3 = document.getElementById("studentID").value;
	if(num1 != num2)
	{
		/*alert("Passwords do not match");*/
		document.getElementById("messages").innerHTML="Passwords do not match";
		return false;
	}
	if(num1.length < 4)
	{
		/*alert("Password should be above 4 characters");*/
		document.getElementById("messages").innerHTML="Password should be above 4 characters";
		return false;
	}
	if(num1.length > 10)
	{
		/*alert("Password should be less than 10 characters");*/
		document.getElementById("messages").innerHTML="Password should be less than 10 characters";
		return false;
	}
	
	if(num3.length != 7)
	{
		/*alert("Student ID should be 7 characters");*/
		document.getElementById("messages").innerHTML="Student ID should be 7 characters";
		return false;
	}
}

