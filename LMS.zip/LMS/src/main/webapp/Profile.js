/**
 * 
 */
  //OPEN PROFILE FORM
function openProfile() {
  	document.getElementById("profile").style.display = "block";
}
//CLOSE PROFILE FORM
function closeProfile() {
  	document.getElementById("profile").style.display = "none";
  	document.getElementById("save").style.display = "none";
  	document.getElementById("firstname").readOnly = "true";
	document.getElementById("lastname").readOnly = "true";
	document.getElementById("email").readOnly = "true";
	document.getElementById("Apassword").readOnly = "true";
}
function editProfile() {
	document.getElementById("save").style.display = "block";
	document.getElementById("firstname").removeAttribute('readonly');
	document.getElementById("lastname").removeAttribute('readonly');
	document.getElementById("email").removeAttribute('readonly');
	document.getElementById("Apassword").removeAttribute('readonly');
}
