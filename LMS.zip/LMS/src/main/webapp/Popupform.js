/**
 * 
 */
 //OPEN MODIFY FORM
function openModify() {
  	document.getElementById("modify").style.display = "block";
	document.getElementById("myForm").style.display = "none";
}
//CLOSE MODIFY FORM
function closeModify() {
  	document.getElementById("modify").style.display = "none";
}

//OPEN DELETE FORM
function openForm() {
  	document.getElementById("myForm").style.display = "block";
  	document.getElementById("modify").style.display = "none";
}
//CLOSE DELETE FORM
function closeForm() {
  	document.getElementById("myForm").style.display = "none";
}