package ntoi.LMS;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/MemberLoginServlet")
public class MemberLoginServlet extends HttpServlet {
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException
	{
		Connection conn = null;
		res.setContentType("text/html");
		PrintWriter out = res.getWriter();
		
		String studentID = req.getParameter("studentID");
		String password = req.getParameter("password");
		String Request = "approved";
		String Request2 = "pending";
		
		String query = "SELECT * FROM LibraryMembers WHERE studentID='"+studentID+"' OR Mpassword='"+password+"' and request='"+Request+"'";
		
		try {
			conn = DBConnection.getConnection();
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery(query);
			
			if(rs.next())
			{
				if(studentID.equals(rs.getString("studentID")) && password.equals(rs.getString("Mpassword")) &&  Request.equals(rs.getString("request")))
				{
					String firstname = rs.getString("firstname");
					String lastname = rs.getString("lastname");
					String email = rs.getString("email");
					String Mpassword = rs.getString("Mpassword");
					
					MemberBean jb = new MemberBean();
					
					jb.setStudentID(studentID);
					jb.setFirstname(firstname);
					jb.setLastname(lastname);
					jb.setEmail(email);
					jb.setMpassword(Mpassword);
					
					HttpSession session = req.getSession();
					session.setAttribute("studentDetails", jb);
					session.setAttribute("studentID", studentID);
					
					//Creating RequestDispatcher object for changing page
					RequestDispatcher rd = req.getRequestDispatcher("MemberMainMenu.jsp");
					rd.forward(req, res);
				}
				else if(studentID.equals(rs.getString("studentID")) && password.equals(rs.getString("Mpassword")) && Request2.equals(rs.getString("request")))
				{
					RequestDispatcher rd = req.getRequestDispatcher("MemberLogin.jsp");
					rd.include(req, res);
					out.println("<h3 style=\"color:red; text-align:center;\">Your Account request has not been Approved<h3>");
				}
				else if(studentID.equals(rs.getString("studentID")) && password != (rs.getString("Mpassword")) && Request.equals(rs.getString("request")))
				{
					RequestDispatcher rd = req.getRequestDispatcher("MemberLogin.jsp");
					rd.include(req, res);
					out.println("<h3 style=\"color:red; text-align:center;\">Password Incorrect<h3>");
				}
				else if(studentID.equals(rs.getString("studentID")) && password != (rs.getString("Mpassword")) && Request2.equals(rs.getString("request")))
				{
					RequestDispatcher rd = req.getRequestDispatcher("MemberLogin.jsp");
					rd.include(req, res);
					out.println("<h3 style=\"color:red; text-align:center;\">Password Incorrect<h3>");
				}
				else 
				{
					RequestDispatcher rd = req.getRequestDispatcher("MemberLogin.jsp");
					rd.include(req, res);
					out.println("<h3 style=\"color:red; text-align:center;\">Your Account request has not been Approved<h3>");
				}
			}
			else
			{
				RequestDispatcher rd = req.getRequestDispatcher("MemberLogin.jsp");
				rd.include(req, res);
				out.println("<h3 style=\"color:red; text-align:center;\">Account Not Found<h3>");
			}
			conn.close();
			st.close();
			rs.close();
		} catch (Exception e) {
			e.printStackTrace();
			out.println("<h3 style=\"color:red; text-align:center;\">SOMETHING WENT WRONG<h3>");
			RequestDispatcher rd = req.getRequestDispatcher("MemberLogin.jsp");
			rd.include(req, res);
		}
		
	}
}
