package ntoi.LMS;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/ProfileServlet")
public class ProfileServlet extends HttpServlet{
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException
	{
		Connection conn = null;
		res.setContentType("text/html");
		PrintWriter out = res.getWriter();
		
		String adminID = req.getParameter("adminID");
		String firstname = req.getParameter("firstname");
		String lastname = req.getParameter("lastname");
		String email = req.getParameter("email");
		String Apassword = req.getParameter("Apassword");
		
		String query= "UPDATE AdminMembers SET firstname='"+firstname+"', lastname='"+lastname
				+"', email='"+email+"', Apassword='"+Apassword+"' WHERE adminID='"+adminID+"'";
		
		try {
			conn = DBConnection.getConnection();
			Statement st = conn.createStatement();
			int count = st.executeUpdate(query);
			
			HttpSession session = req.getSession();
			session.removeAttribute("AdminDetails");
			
			UseBean jb = new UseBean();
			jb.setAdminID(adminID);
			jb.setFirstname(firstname);
			jb.setLastname(lastname);
			jb.setEmail(email);
			jb.setApassword(Apassword);
			
			session.setAttribute("adminDetails", jb);
			
			RequestDispatcher rd = req.getRequestDispatcher("AdminMainMenu.jsp");
			rd.forward(req, res);
			out.println("done");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
