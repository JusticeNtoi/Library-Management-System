package ntoi.LMS;

import java.io.Serializable;

public class UseBean implements Serializable {
	protected String adminID;
	protected String firstname;
	protected String lastname;
	protected String email;
	protected String Apassword;
	
	public UseBean()
	{
		adminID = " ";
		firstname = " ";
		lastname = " ";
		email = " ";
		Apassword = " ";
	}

	public String getAdminID() {
		return adminID;
	}

	public void setAdminID(String adminID) {
		this.adminID = adminID;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}
 
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getApassword() {
		return Apassword;
	}

	public void setApassword(String apassword) {
		Apassword = apassword;
	}
	
}
