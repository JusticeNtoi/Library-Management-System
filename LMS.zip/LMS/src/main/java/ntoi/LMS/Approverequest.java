package ntoi.LMS;

import java.sql.Statement;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Approve")
public class Approverequest extends HttpServlet{
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException
	{
		Connection conn = null;
		res.setContentType("text/html");
		PrintWriter out = res.getWriter();
		
		String studentID = req.getParameter("studentID");
		String Request = "approved";
		
		String query ="UPDATE LibraryMembers SET request='"+Request+"' WHERE studentID='"+studentID+"'";
		
		
		try {
			conn = DBConnection.getConnection();
			Statement st = conn.createStatement();
			int count = st.executeUpdate(query);
			
			RequestDispatcher rd = req.getRequestDispatcher("Requests.jsp");
			rd.forward(req, res);
			out.print("Approved");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
