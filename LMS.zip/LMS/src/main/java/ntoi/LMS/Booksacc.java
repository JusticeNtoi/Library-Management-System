package ntoi.LMS;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Booksacc")
public class Booksacc extends HttpServlet {
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException
	{
		Connection conn = null;
		res.setContentType("text/html");
		PrintWriter out = res.getWriter();
		
		String bookname = req.getParameter("bookname");
		
		req.setAttribute("bookname", bookname);
		
		RequestDispatcher rd = req.getRequestDispatcher("ACCReservebook.jsp");
		rd.forward(req, res);
	}
}
