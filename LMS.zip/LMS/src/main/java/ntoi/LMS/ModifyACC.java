package ntoi.LMS;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ModifyACC")
public class ModifyACC extends HttpServlet {
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException
	{
		Connection conn = null;
		res.setContentType("text/html");
		PrintWriter out = res.getWriter();
		
		String title = req.getParameter("title");
		String booktitle = req.getParameter("booktitle");
		String author = req.getParameter("author");
		String rackdetails = req.getParameter("rackdetails");
		String faculty = req.getParameter("faculty");
		
		String query= "UPDATE BookTitles SET booktitle='"+booktitle+"', author='"+author
				+"', rackdetails='"+rackdetails+"', faculty='"+faculty+"' WHERE booktitle='"+title+"'";
		
		try {
			conn = DBConnection.getConnection();
			Statement st = conn.createStatement();
			
			int count = st.executeUpdate(query);
			
			RequestDispatcher rd = req.getRequestDispatcher("Accountingbooks.jsp");
			out.print("BOOK SUCCESSFULLY MODIFIED");
			rd.forward(req, res);
			
			conn.close();
			st.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
