package ntoi.LMS;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Refresh")
public class Refresh extends HttpServlet {
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException
	{
		Connection conn = null;
		res.setContentType("text/html");
		PrintWriter out = res.getWriter();
		
		String duestatus = "ondue";
		String duestatus1 = "overdue";
		
		String query = "SELECT * FROM Reserved WHERE duestatus='"+duestatus+"'";
		String query1 = "UPDATE Reserved SET duestatus='"+duestatus1+"' WHERE booknumber=?";
		
		SimpleDateFormat simple = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		
		Date current = new Date();
		
		try {
			conn = DBConnection.getConnection();
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery(query);
			
			while(rs.next())
			{
				int booknumber = Integer.parseInt(rs.getString("booknumber"));
				
				String due = rs.getString("duedate");
				Date duedate = simple.parse(due);
				
				long difference_In_Time = current.getTime() - duedate.getTime();
				
				long difference_In_Days = (difference_In_Time / (1000 * 60 * 60 * 24))% 365;
				
				if(difference_In_Days > 0)
				{
					PreparedStatement pst = conn.prepareStatement(query1);
					
					pst.setInt(1, booknumber);
					
					int count = pst.executeUpdate();
						
				}
				
			}
			RequestDispatcher rd = req.getRequestDispatcher("Issuedbooks.jsp");
			rd.forward(req, res);
				
			conn.close();
			st.close();
			rs.close();
		} catch (Exception e) {
			e.printStackTrace();
		} 
		
	}
}
