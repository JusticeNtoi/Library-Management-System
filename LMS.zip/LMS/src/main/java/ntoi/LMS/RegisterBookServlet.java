package ntoi.LMS;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/RegisterBookServlet")
public class RegisterBookServlet extends HttpServlet{
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException
	{
		Connection conn = null;
		res.setContentType("text/html");
		PrintWriter out = res.getWriter();
		
		String booknumber = req.getParameter("booknumber");
		String booktitle = req.getParameter("booktitle");
		String author = req.getParameter("author");
		String rackdetails = req.getParameter("rackdetails");
		String faculty = req.getParameter("faculty");
		String bookstatus = "Available";
		
		String query1 = "SELECT * FROM BookTitles WHERE booktitle='"+booktitle+"'";
		String query2 = "INSERT INTO BookTitles VALUES ('"+booktitle+"','"+author
				+"','"+rackdetails+"','"+faculty+"')";
		
		String Query = "SELECT * FROM Books WHERE booknumber='"+booknumber+"'";
		String query = "INSERT INTO Books VALUES ('"+booknumber+"','"+booktitle+"','"+bookstatus+"')";
		
		String Query1 = "SELECT * FROM Books WHERE booktitle='"+booktitle+"'";
		String Query2 = "DELETE FROM BookTitles WHERE booktitle='"+booktitle+"'";
		
		//CHECKING FOR THE BOOK TITLE IF IT IS ALREADY IN THE BOOKTITLES DATABASE OR NOT
		//IF IT IS REGISTERED, THE BOOK IS ADDED IN BOOKS DATABASE
		try {
			conn = DBConnection.getConnection();
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery(query1);
			
			if(rs.next())
			{
				System.out.println("Book Already in the System");
			}
			else
			{
				int count = st.executeUpdate(query2);
			}
			conn.close();
			st.close();
			rs.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		try {
			conn = DBConnection.getConnection();
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery(Query);
			if(rs.next())
			{
				rs = st.executeQuery(Query1);
				if(rs.next())
				{
					
				}
				else
				{
					int count = st.executeUpdate(Query2);
				}
				RequestDispatcher rd = req.getRequestDispatcher("RegisterBook.jsp");
				rd.include(req, res);
				out.println("<h3 style=\"color:red; text-align:center;\">Book number Already used<h3>");
			}
			else 
			{
				int count = st.executeUpdate(query);
				
				RequestDispatcher rd = req.getRequestDispatcher("RegisterBook.jsp");
				rd.forward(req, res);
				out.print("BOOK SUCCESSFULLY ADDED");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
