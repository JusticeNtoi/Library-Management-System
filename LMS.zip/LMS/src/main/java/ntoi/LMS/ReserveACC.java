package ntoi.LMS;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/ReserveACC")
public class ReserveACC extends HttpServlet {
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException
	{
		Connection conn = null;
		res.setContentType("text/html");
		PrintWriter out = res.getWriter();
		
		//SETTING DATA FORMAT
		String DATEFORMAT = "dd/MM/yyyy HH:mm:ss";
	    DateFormat dateFormat = new SimpleDateFormat(DATEFORMAT);
	    
		
		HttpSession session = req.getSession();
		String studentID = (String) session.getAttribute("studentID");
		
		String booknumber = req.getParameter("booknumber");
		
		//GET CURRENT TIME
		Date currentdate = new Date();
		String reservedate = dateFormat.format(currentdate);
		// convert date to localdatetime
		LocalDateTime localDateTime = currentdate.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
		
		 // plus five days
		localDateTime = localDateTime.plusYears(0).plusMonths(0).plusDays(5);
        localDateTime = localDateTime.plusHours(0).plusMinutes(0).minusMinutes(0).plusSeconds(0);
		
     // convert LocalDateTime to date
        Date dueDate = Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
        String duedate = dateFormat.format(dueDate);
        
        String duestatus = "ondue";
        String bookstatus = "Reserved";
        
        String query = "INSERT INTO Reserved VALUES ('"+studentID+"','"+booknumber+"','"+reservedate+"','"+duedate+"','"+duestatus+"')";
        String query2= "UPDATE Books SET bookstatus='"+bookstatus+"' WHERE booknumber='"+booknumber+"'";
        
        try {
			conn = DBConnection.getConnection();
			Statement st = conn.createStatement();
			
			int count = st.executeUpdate(query);
			int count2 = st.executeUpdate(query2);
			
			RequestDispatcher rd = req.getRequestDispatcher("ACCreserve.jsp");
			rd.forward(req, res);
			
				
			conn.close();
			st.close();
		} catch (Exception e) {
			e.printStackTrace();
		} 
	}
}
