package ntoi.LMS;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/AdminLoginServlet")

public class AdminLoginServlet extends HttpServlet {
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException
	{
		Connection conn = null;
		res.setContentType("text/html");
		PrintWriter out = res.getWriter();
		
		String adminID = req.getParameter("adminID");
		String password = req.getParameter("password");
		
		String query = "SELECT * FROM AdminMembers WHERE adminID='"+adminID+"' OR Apassword='"+password+"'";
		
		try {
			conn = DBConnection.getConnection();
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery(query);
			
			if(rs.next())
			{
				if(adminID.equals(rs.getString("adminID")) && password.equals(rs.getString("Apassword")))
				{
					UseBean jb = new UseBean();
					
					String firstname = rs.getString("firstname");
					String lastname = rs.getString("lastname");
					String email = rs.getString("email");
					String Apassword = rs.getString("Apassword");
					
					jb.setAdminID(adminID);
					jb.setFirstname(firstname);
					jb.setLastname(lastname);
					jb.setEmail(email);
					jb.setApassword(Apassword);
					
					HttpSession session = req.getSession();
					session.setAttribute("adminDetails", jb);
					session.setAttribute("adminID", adminID);
					
					//Creating RequestDispatcher object for changing page
					RequestDispatcher rd = req.getRequestDispatcher("AdminMainMenu.jsp");
					rd.forward(req, res);
				}
				else if(adminID.equals(rs.getString("adminID")))
				{
					RequestDispatcher rd = req.getRequestDispatcher("AdminLogin.jsp");
					rd.include(req, res);
					out.println("<h3 style=\"color:red; text-align:center;\">Password Incorrect<h3>");
				}
				else if(password.equals(rs.getString("Apassword")))
				{
					RequestDispatcher rd = req.getRequestDispatcher("AdminLogin.jsp");
					rd.include(req, res);
					out.println("<h3 style=\"color:red; text-align:center;\">Admin ID or Password Incorrect<h3>");
				}
			}
			else
			{
				RequestDispatcher rd = req.getRequestDispatcher("AdminLogin.jsp");
				rd.include(req, res);
				out.println("<h3 style=\"color:red; text-align:center;\">Account Not Found<h3>");
			}
			conn.close();
			st.close();
			rs.close();
		} catch (Exception e) {
			e.printStackTrace();
			RequestDispatcher rd = req.getRequestDispatcher("AdminLogin.jsp");
			rd.include(req, res);
			out.println("<h3 style=\"color:red; text-align:center;\">SOMETHING WENT WRONG<h3>");
		}
		
	}
}
