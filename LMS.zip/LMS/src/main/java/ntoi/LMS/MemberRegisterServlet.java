package ntoi.LMS;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;

@WebServlet("/MemberRegisterServlet")
public class MemberRegisterServlet extends HttpServlet{
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException
	{
		Connection conn = null;
		res.setContentType("text/html");
		PrintWriter out = res.getWriter();
		
		String studentID = req.getParameter("studentID");
		String firstname = req.getParameter("firstname");
		String lastname = req.getParameter("lastname");
		String gender = req.getParameter("gender");
		String email = req.getParameter("email");
		String password = req.getParameter("password");
		String request = "pending";
		
		String Query = "SELECT * FROM librarymembers WHERE studentID='"+studentID+"'";
		String query = "INSERT INTO librarymembers VALUES ('"+studentID+"','"+firstname+"','"+lastname+"','"+gender+"','"+email+"','"+password+"','"+request+"')";
		
		try {
			conn = DBConnection.getConnection();
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery(Query);
			
			if(rs.next())
			{
				RequestDispatcher rd = req.getRequestDispatcher("Register.jsp");
				rd.forward(req, res);
				 out.println("<h1 style=\"color:red; text-align:center;\">Student ID has Already been used!<h1>"); 
			}
			else
			{
				int count = st.executeUpdate(query);
				
				RequestDispatcher rd = req.getRequestDispatcher("Register.jsp");
				rd.forward(req, res);
				out.print("<h1 style=\"color:red; text-align:center;\">SUCCESSFULLY REGISTERED<h1>");
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
