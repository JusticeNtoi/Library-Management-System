package ntoi.LMS;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
	private static String url = "jdbc:mysql://localhost:3306/LMSdatabase";
	private static String user = "root";
	private static String password = "";
	
	public static Connection getConnection()
	{
		Connection con = null;
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(url,user,password);
			//System.out.println("Database connection success!");
		}
		catch(ClassNotFoundException c) {
			System.out.println("Could not load the JDBC driver: " + c.getMessage());
		}catch(SQLException e) {
			System.out.println("Database connection failed!" + e.getMessage());
		}
		return con;
	}
}
