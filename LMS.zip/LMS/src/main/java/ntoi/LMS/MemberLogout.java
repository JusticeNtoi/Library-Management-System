package ntoi.LMS;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/MemberLogout")
public class MemberLogout extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//When logging out, we simply/technically are removing our previously sessioned login data (e.g. 
		//the Admin id.  So, when we logout, we remove the session data using the session.removeAttribute() method
		
		HttpSession session = request.getSession();
		session.removeAttribute("studentID");
		session.removeAttribute("studentDetails");
		session.invalidate();
		response.sendRedirect("MemberLogin.jsp");
	}
}
